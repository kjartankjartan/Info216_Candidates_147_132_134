import com.github.jsonldjava.utils.JsonUtils;
import org.apache.jena.datatypes.xsd.XSDDatatype;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.riot.Lang;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.vocabulary.RDF;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.util.*;
import java.util.stream.IntStream;


public class test{
    static final String relationshipUri = "http://purl.org/ontology/fo/";
    private Model model;
    final String url = "src/Ontolog216.owl";
    public static Model modelss = ModelFactory.createDefaultModel();




     // Create the types of Property we need to describe relationships
         // in the model


        Property hasMeasurement = modelss.createProperty(relationshipUri,"hasMeasurement");
        Property caloriesPer100g = modelss.createProperty(relationshipUri,"caloriesPer100g");
        Property hasCalories = modelss.createProperty(relationshipUri,"hasCalories");
        Property typeof = modelss.createProperty(relationshipUri,"typeOf");
        Property contains = modelss.createProperty(relationshipUri,"contains");
        Property usedIn = modelss.createProperty(relationshipUri,"usedIn");
        Property hasSteps = modelss.createProperty(relationshipUri,"hasSteps");
        Property hasCookingTime = modelss.createProperty(relationshipUri,"hasCookingTime");
        Property isAllergenOf = modelss.createProperty(relationshipUri,"isAllergenOf");
        Property hasAllergen = modelss.createProperty(relationshipUri,"hasAllergen");
        Property isDietrestrictionOf = modelss.createProperty(relationshipUri,"isDietrestrictionOf");
        Property hasDietrestriction = modelss.createProperty(relationshipUri,"hasDietrestriction");




     //Create resources representing the classes in our model

     Resource step = modelss.getResource("http://purl.org/ontology/fo/Step/#");
     Resource food = modelss.getResource("http://purl.org/ontology/fo/Food/#" );
     Resource recipe = modelss.getResource("http://purl.org/ontology/fo/Recipe/#" );
     Resource dietRestriction = modelss.getResource("http://purl.org/ontology/fo/DietRestriction/#" );
     Resource allergen = modelss.getResource("http://purl.org/ontology/fo/info216#Allergens/#" );
     Resource quantitativeValue = modelss.getResource("http://schema.org/Quantity/#");
     Resource measurement = modelss.getResource("http://purl.org/ontology/fo/Measurement/#");
     Resource timeOfCooking = modelss.getResource("http://dublincore.org/usage/terms/history/#PeriodOfTime-001/#");
     Resource description = modelss.getResource("http://dublincore.org/usage/terms/history/#description-006/#");





    public test (){

    }

    public void readAndAddshortData() throws Exception {

       modelss.read(url);
       // parsing file "Recipes.json"
       Object obj = new JSONParser().parse(new FileReader("src/food_data.json"));

       JSONObject itemObj = (JSONObject) obj;

       //Creating a JSONArray from the object
       ArrayList getTheIngredients =(ArrayList) itemObj.get("ingredients");

       for (int i = 0; i < getTheIngredients.size(); i++) {


             JSONObject item = (JSONObject)getTheIngredients.get(i);
             String ingredientname =(String) item.get("name");
           System.out.println(ingredientname);

             String ingredientsname =ingredientname.replaceAll("\\s{2,}", " ").trim();

             Double ingredientscals =(Double) item.get("calories");

             String totalCals = Double.toString(ingredientscals);

             Resource ingredientsList = modelss.createResource(food+ingredientsname);
             Resource caloriesIngredients = modelss.createResource(quantitativeValue +"quantitativeValue");

             Resource cals = modelss.createResource();



          ingredientsList.addProperty(hasCalories,cals);
          cals.addProperty(RDF.type, quantitativeValue);
           cals.addLiteral(caloriesPer100g, ingredientscals);



             //If statements that checks if food categories contains allergens
           if (ingredientsname.contains("soy")){
               Resource allergy = modelss.createResource(allergen+"soy");
               ingredientsList.addProperty(hasAllergen, allergy);
               allergy.addProperty(isAllergenOf,ingredientsList);

           }



           if (ingredientsname.contains("cupcake") || ingredientsname.contains("ice cream") || ingredientsname.contains("latte") ||ingredientsname.contains("milk") ||ingredientsname.contains("pie") ||ingredientsname.contains("butter") ||ingredientsname.contains("yogurt") ){

                   Resource allergy = modelss.createResource(allergen+"lactose");
                   ingredientsList.addProperty(hasAllergen, allergy);
                   allergy.addProperty(isAllergenOf,ingredientsList);

           }

           if (ingredientsname.contains("cheese")){
               Resource allergy = modelss.createResource(allergen+"lactose");
               ingredientsList.addProperty(hasAllergen, allergy);
               allergy.addProperty(isAllergenOf,ingredientsList);

           }

           if (ingredientsname.contains("peanut")){
               Resource allergy = modelss.createResource(allergen+"peanut");
               ingredientsList.addProperty(hasAllergen, allergy);
               allergy.addProperty(isAllergenOf,ingredientsList);

           }


           if (ingredientsname.contains("nuts")){
               Resource allergy= modelss.createResource(allergen+"nuts");
               ingredientsList.addProperty(hasAllergen, allergy);
               allergy.addProperty(isAllergenOf,ingredientsList);

           }

           if (ingredientsname.contains("pizza") ||ingredientsname.contains("pie") || ingredientsname.contains("flour")|| ingredientsname.contains("bbq") ||ingredientsname.contains("pancake") ||ingredientsname.contains("bun") ||ingredientsname.contains("cake") ||ingredientsname.contains("starch") || ingredientsname.contains("malt") ||ingredientsname.contains("couscous") ||ingredientsname.contains("bulgur") ||ingredientsname.contains("bran") || ingredientsname.contains("batter") ||ingredientsname.contains("muffins") || ingredientsname.contains("muffin") || ingredientsname.contains("wheat") || ingredientsname.contains("quesadilla") || ingredientsname.contains("bread")){
               Resource allergy = modelss.createResource(allergen+"gluten");
               ingredientsList.addProperty(hasAllergen, allergy);
               allergy.addProperty(isAllergenOf,ingredientsList);

           }

           if (ingredientsname.contains("tuna") ||ingredientsname.contains("seafood") ||ingredientsname.contains("fish") || ingredientsname.contains("worcestershire sauce") || ingredientsname.contains("caesar") || ingredientsname.contains("caponata") ){
               Resource allergy = modelss.createResource(allergen+"fish");
               ingredientsList.addProperty(hasAllergen, allergy);
               allergy.addProperty(isAllergenOf,ingredientsList);


               Resource dietrestriction= modelss.createResource(dietRestriction+"pescetarian");

               ingredientsList.addProperty(hasDietrestriction, dietrestriction);
               dietrestriction.addProperty(isDietrestrictionOf,ingredientsList);


           }

           if (ingredientsname.contains("seafood") || ingredientsname.contains("shrimp")||ingredientsname.contains("crab")|| ingredientsname.contains("mussels") || ingredientsname.contains("oysters") || ingredientsname.contains("clams")){
               Resource allergy= modelss.createResource(allergen+"shellfish");
               ingredientsList.addProperty(hasAllergen, allergy);
               allergy.addProperty(isAllergenOf,ingredientsList);



               Resource dietrestriction= modelss.createResource(dietRestriction+"pescetarian");
               ingredientsList.addProperty(hasDietrestriction, dietrestriction);
               dietrestriction.addProperty(isDietrestrictionOf,ingredientsList);


           }

           if (ingredientsname.contains("hollandaise")|| ingredientsname.contains("pasta")||ingredientsname.contains("meringue")||ingredientsname.contains("meatballs")|| ingredientsname.contains("meatloaf")||ingredientsname.contains("mayonnaise")||ingredientsname.contains("cappuccino")|| ingredientsname.contains("ice cream")|| ingredientsname.contains("pudding")|| ingredientsname.contains("egg")|| ingredientsname.contains("waffle") || ingredientsname.contains("batter") || ingredientsname.contains("breaded")|| ingredientsname.contains("cream pies") || ingredientsname.contains("caesar dressing")){
               Resource allergy= modelss.createResource(allergen+"egg");
               ingredientsList.addProperty(hasAllergen, allergy);
               allergy.addProperty(isAllergenOf,ingredientsList);

           }

           List<String> noneVegetarian = new ArrayList<String>() {{
               add("ham");
               add("pork");
               add("beef");
               add("liver");
               add("chicken");
               add("bacon");
               add("bratwurst");
               add("venison");
               add("meat");
               add("lamb");
               add("steak");
               add("veal");
               add("turkey");
               add("hen");
               add("duck");
               add("hot dog");
               add("bologna");
               add("sausage");
               add("frankfurter");
               add("gumbo");

           }};




           List<String> noneVegan = new ArrayList<String>() {{
               add("milk");
               add("cheese");
               add("butter");
               add("egg");
               add("pie");
               add("yogurt");
               add("hollandaise");
               add("pasta");
               add("meringue");
               add("mayonnaise");
               add("cappuccino");
               add("latte");
               add("ice cream");
               add("pudding");
               add("waffle");
               add("batter");
               add("breaded");
               add("cream pie");
               add("caesar dressing");
               add("gumbo");
               add("seafood");
               add("shrimp");
               add("crab");
               add("mussels");
               add("ice cream");
               add("oysters");
               add("waffle");
               add("clams");
               add("breaded");
               add("cream pie");
               add("caesar");
               add("gumbo");
               add("seafood");
               add("fish");
               add("tuna");
               add("cupcake");
               add("ice cream");

           }};

           String notmeat = "";

           for (int xx = 0; xx < noneVegetarian.size(); xx++) {
               String test = noneVegetarian.get(xx);
               if (ingredientsname.contains(test)){
                   String noneveg = ingredientsname;
                   String noveg = noneveg;
                   notmeat = noveg;
               }
           }

           String notvegan = "";

           for (int xy = 0; xy < noneVegan.size(); xy++) {
               String findNotvegan = noneVegan.get(xy);
               if (ingredientsname.contains(findNotvegan)){
                   String notvanism = ingredientsname;
                   String checknotvanism = notvanism;
                   notvegan = checknotvanism;
               }
           }

           if(!ingredientsname.equals(notmeat)){
               String notMeat = ingredientsname;
               Resource vegetarianList = modelss.createResource(food+notMeat);
               Resource dietrestriction= modelss.createResource(dietRestriction+"vegetarian");

               vegetarianList.addProperty(hasDietrestriction, dietrestriction);
               dietrestriction.addProperty(isDietrestrictionOf,vegetarianList);

           }

           if(!ingredientsname.equals(notmeat) && !ingredientsname.equals(notvegan) ){
               String justVegan = ingredientsname;

               Resource justVeganList = modelss.createResource(food+justVegan);
               Resource dietrestriction= modelss.createResource(dietRestriction+"vegan");

               justVeganList.addProperty(hasDietrestriction, dietrestriction);
               dietrestriction.addProperty(isDietrestrictionOf,justVeganList);

           }




           //If Statements to create diet restriction

           if (ingredientsname.contains("veggie burger")||ingredientsname.contains("vegetarian")||ingredientsname.contains("meatless")){
               Resource dietrestriction= modelss.createResource(dietRestriction+"vegetarian");
               ingredientsList.addProperty(hasDietrestriction, dietrestriction);
               dietrestriction.addProperty(isDietrestrictionOf,ingredientsList);

           }

           if (ingredientsname.contains("vegetarian")||ingredientsname.contains("wrap sandwich vegetables rice")||ingredientsname.contains("meatless")){
               Resource dietrestriction= modelss.createResource(dietRestriction+"vegan");
               ingredientsList.addProperty(hasDietrestriction, dietrestriction);
               dietrestriction.addProperty(isDietrestrictionOf,ingredientsList);

           }
        }
    }


    public void readAndAddLongData() throws Exception {

        modelss.read(url);
        // parsing file "Recipes.json"
        Object obj = new JSONParser().parse(new FileReader("src/Recipes.json"));

        //Creating a JSONArray from the object
        JSONArray testest = (JSONArray) obj;

        //Itterating through the json array. To get the whole file, just remove the commented out section and delete the "1"
        for (int n = 0; n < testest.size(); n++) {
            //Convert the objects inside json array to JSONObjects
            JSONObject itemObj = (JSONObject) testest.get(n);

            //Printing out the name for the recipe
            String itemId = (String) itemObj.get("name");


            Resource nameOfFood = modelss.createResource(recipe + itemId);


            //Get the ingredients array. It is a nested array inside the JSONArray object
            JSONArray ingre = (JSONArray) itemObj.get("ingredients");


            //Getting all the objects inside the jsonArray
            Iterator<Map.Entry> getJsonData = itemObj.entrySet().iterator();
            while (getJsonData.hasNext()) {
                Map.Entry pair = getJsonData.next();

            }

            String quantitystring = "";
            String foodCategory = "";



            // Getting the ingredients list
            Iterator getIngredients = ingre.iterator();

            while (getIngredients.hasNext()) {


                getJsonData = ((Map) getIngredients.next()).entrySet().iterator();
                while (getJsonData.hasNext()) {
                    Map.Entry pair = getJsonData.next();
                    Object testtest = pair.getValue();
                    Object testtest1 = pair.getKey();
                    String test = testtest.toString().toLowerCase();
                    String test1 = testtest1.toString().toLowerCase();


                    //Trying to get the quantity, but this code does not work propperly due to it doesmt update until outside of loop

                    if (pair.getKey().equals("quantity")) {
                        Object getquant = pair.getValue();
                        String quant = getquant.toString().toLowerCase();
                        String quantit = quant;
                        quantitystring = quantit;
                    }

                    if (pair.getKey().equals("type")) {
                        Object gettype = pair.getValue();
                        String types = gettype.toString().toLowerCase();
                        String typeOf = types;
                        foodCategory = typeOf;
                    }


                    Resource quantityFood = modelss.createResource();
                    Resource quantityOfFood = modelss.createResource(measurement + quantitystring);
                    Resource typeofFood = modelss.createResource( description+ foodCategory);



                    //Get the name of ingredient
                    if (pair.getKey().equals("name")) {
                        Object getname = pair.getValue();
                        String ingrName = getname.toString().toLowerCase();

                        Resource ingredientsList = modelss.createResource(food + ingrName);
                        nameOfFood.addProperty(contains, ingredientsList);
                        ingredientsList.addProperty(usedIn,nameOfFood);
                        ingredientsList.addProperty(hasMeasurement, quantityOfFood);
                        ingredientsList.addProperty(typeof, typeofFood);

                    }
                }
            }


            //Get the array of steps and add it to the modell
            ArrayList steps = (ArrayList) itemObj.get("steps");
            String stepCommaSeparated = String.join(" ", steps);
            Resource getStepList = modelss.createResource(step + stepCommaSeparated);
            nameOfFood.addProperty(hasSteps, getStepList);


            //modelss.add(modelss.createStatement(nameOfFood, hasSteps, getStepList));


            //Get the List element "timers"
            List timers = (List) itemObj.get("timers");
            int totalsum = 0;

            for (int i = 0; i < timers.size(); i++) {
                System.out.println(timers.get(i));
                Object sums = timers.get(i);
                Long age = (Long) sums;
                totalsum += age;
            }

            //Add the cooking time to the model

            int totalsums = IntStream.of(totalsum).sum();
            String totalsummedTimer = Integer.toString(totalsums);
            Resource getTotalTime = modelss.createResource(timeOfCooking + "cookingtime");

            nameOfFood.addProperty(hasCookingTime,totalsummedTimer, XSDDatatype.XSDinteger);

        }
    }



    public void writeModel(){
        modelss.write(System.out, "ttl");
    }


    public void createModelAndRead() throws Exception{

        OutputStream out = new FileOutputStream("models.ttl");
        RDFDataMgr.write(out,modelss, Lang.TURTLE);
    }


    public static void main(String[] args) throws Exception {


        test jsonobj = new test();

        jsonobj.readAndAddLongData();
        jsonobj.readAndAddshortData();
        jsonobj.writeModel();
        jsonobj.createModelAndRead();

        //This would be the better way to create the SPARQL queries for quering our model, but we get an error that we are unable to resolve.
        // Exception in thread "main" java.lang.ClassCastException: org.apache.jena.rdf.model.impl.ResourceImpl cannot be cast to org.apache.jena.rdf.model.Literal
       /* String queryString =
                "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
                "PREFIX foaf: <http://xmlns.com/foaf/0.1/> " +
                "PREFIX fo:  <http://purl.org/ontology/fo/> " +
                "SELECT * WHERE { " +
            " ?ingredient fo:hasAllergen ?x ." +
                    "}";
                Query query = QueryFactory.create(queryString);
            QueryExecution qexec = QueryExecutionFactory.create(query, modelss);
            try {

                ResultSet results = qexec.execSelect();
                while (results.hasNext()) {
                    QuerySolution soln = results.nextSolution();
                    Literal name = soln.getLiteral("x");
                    System.out.println(name);
                }
            } finally {
                qexec.close();
            }
                }}
    */


//Run this to find all food with diet restrictions (Vegan, vegetarian, pescetarian)


        ResultSet resultSet = QueryExecutionFactory
                .create("PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
                        "PREFIX foaf: <http://xmlns.com/foaf/0.1/> " +
                        "PREFIX fo:  <http://purl.org/ontology/fo/> " +
                        "SELECT * WHERE { " +
                        " ?food fo:hasDietrestriction ?allergy ." +
                        "}", modelss)
                .execSelect();

        resultSet.forEachRemaining(qsol -> System.out.println(qsol.toString()));


        //Run this to select all the food that contains allergens, and their corresponding allergens, i.e American cheese contains lactose.
      /*  ResultSet resultSet = QueryExecutionFactory
                .create("PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
                        "PREFIX foaf: <http://xmlns.com/foaf/0.1/> " +
                        "PREFIX fo:  <http://purl.org/ontology/fo/> " +
                        "SELECT * WHERE { " +
                        " ?food fo:hasAllergen ?allergy ." +
                        "}", modelss)
                .execSelect();

        resultSet.forEachRemaining(qsol -> System.out.println(qsol.toString()));
*/
      //run this to print all the Ingredients used in a recipe, in this case all the ingredients used in Oatmeal Cookies
       /*
        ResultSet resultSet = QueryExecutionFactory
                .create("PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
                        "PREFIX foaf: <http://xmlns.com/foaf/0.1/> " +
                        "PREFIX fo:  <http://purl.org/ontology/fo/> " +
                        "SELECT ?ingredient ?recipe WHERE { " +
                        " ?ingredient fo:usedIn ?recipe ." +
                        FILTER regex(str(?recipe), "Oatmeal Cookies") +
                        "}", modelss)
                .execSelect();

        resultSet.forEachRemaining(qsol -> System.out.println(qsol.toString()));
    */
       //Selects all the different types of food, i.e baking, produce, dairy, meat
        /*
        ResultSet resultSet = QueryExecutionFactory
                .create("PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
                        "PREFIX foaf: <http://xmlns.com/foaf/0.1/> " +
                        "PREFIX fo:  <http://purl.org/ontology/fo/> " +
                        "SELECT * WHERE  { " +
                        " ?foodtype fo:typeOf ?food ." +
                        "}", modelss)
                .execSelect();

        resultSet.forEachRemaining(qsol -> System.out.println(qsol.toString()));

        */

//Not finished
       /*
        ResultSet resultSet = QueryExecutionFactory
                .create("PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
                        "PREFIX foaf: <http://xmlns.com/foaf/0.1/> " +
                        "PREFIX fo:  <http://purl.org/ontology/fo/> " +
                        "SELECT ?ingredient " +
                        "WHERE {" +
                        "?x rdf:type fo:food . " +
                        "?recipe a fo:Food . " +

                        "}", modelss)
                .execSelect();

        resultSet.forEachRemaining(qsol -> System.out.println(qsol.toString()));
*/
        //Converts the resultSet into a JSON object. JSON object can be used with a frontend framework like javafx to display to results of sparql queries.
        List<Map> jsonList = new Vector<Map>();
        while (resultSet.hasNext()) {
            QuerySolution qsol = resultSet.nextSolution();
            Iterator<String> varNames = qsol.varNames();
            Map<String, Object> jsonMap = new HashMap<String, Object>();
            while (varNames.hasNext()) {
                String varName = varNames.next();
                jsonMap.put(varName, qsol.get(varName).toString());
            }
            jsonList.add(jsonMap);
        }
        System.out.println(JsonUtils.toPrettyString(jsonList));
        }
    }











